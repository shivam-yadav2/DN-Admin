<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class technology extends Model
{
    protected $table='technology';

    protected $fillable = ['img', 'heading'];
}
