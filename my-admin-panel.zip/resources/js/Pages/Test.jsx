export default function Test() {
    console.log("Test page rendered");
    return <h1>✅ Test page rendered</h1>;
}
